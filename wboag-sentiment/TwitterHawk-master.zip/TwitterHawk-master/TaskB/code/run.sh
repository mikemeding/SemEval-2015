python train.py
python predict.py
python evaluate.py -e
