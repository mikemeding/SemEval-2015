python train.py -t ../data/twitter-train-cleansed-B.tsv
python test.py
